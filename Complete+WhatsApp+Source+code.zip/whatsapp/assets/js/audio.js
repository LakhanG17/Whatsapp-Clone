var base_url="http://localhost/whatsapp/";
handleSuccess=function(stream){
    console.log('getUserMedia() got stream:',stream);
    console.log(stream);
    const option={
        mimeType:'audio/webm'
    };

    const recordedChunks=[];
    const mediaRecorder=new MediaRecorder(stream,option);
    mediaRecorder.addEventListener("dataavailable",function(e){
        if(e.data.size >0) recordedChunks.push(e.data);
    })

    mediaRecorder.addEventListener("stop",function(){
        var receiver=$(".u-p-id").data("profileid");
        var sender=$(".u-p-id").data("userid");
        let form_data=new FormData();
        form_data.append("audioFile",recordedChunks[0]);
        form_data.append("receiver",receiver);
        form_data.append("sender",sender);
        $.ajax({
            url:"http://localhost/whatsapp/core/ajax/audio.php",
            cache:false,
            contentType:false,
            processData:false,
            data:form_data,
            type:"POST",
            success:function(audio){
                var data=JSON.parse(audio);
                if(data.status=="error"){  
                    $(".files-error").addClass("show-file-error");
                    $(".files-error").html('<span class="files-cross-icon">&#x2715;</span>'+data.message+'');
                    setTimeout(function(){
                        $(".files-error").removeClass("show-file-error");
                    },5000);
                    return false;
                }else{
                    let result={messageTo:receiver,message:data.message,type:"NEW_AUDIO"};
                    let date=new Date;
                    let time=date.toLocaleString('en-US',{
                        hour:"numeric",
                        hour12:true,
                        minute:"numeric"
                    });

                    let message='<div class="sender audio-file"><span class="sender-message"><audio src="' +base_url+data.message+ '" controls></audio></span> <span class="message-time">'+time+'</span></div>';
                    messageContainer.append(message);
                    sendToOtherUser(conn,result);
                    $(".fileUpload").val("");
                    scrollItself();
                    userLoad();
                }
               
            }
        })
        
    })
    $(document).on("click","#startRecording",function(){
        mediaRecorder.start();
        $(".r-container").show(500);
    }) 
    
    $(document).on("click","#stopRecording",function(){
        mediaRecorder.stop();
        $(".r-container").hide();
    })
    
}


function init(constrain){
    try {
        navigator.mediaDevices.getUserMedia(constrain).then(handleSuccess);
       
    } catch (error) {
        console.error(`navigator.getUserMedia.error: `,error);
    }
}

const constraints={
    audio:true,
    video:false
}

init(constraints);