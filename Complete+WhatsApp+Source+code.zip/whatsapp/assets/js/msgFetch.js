    
    function userLoad(){
        var loadUserId=$(".u-p-id").data("userid");
        var otheruserId=$(".u-p-id").data("profileid");
       
        $.post("http://localhost/whatsapp/core/ajax/msgFetch.php",{userId:loadUserId,profileId:otheruserId},function(data){
            $(".recentMessages").html(data);
        });
    }
    

    userLoad();

   
