$(function(){
    $(".textArea").emojioneArea({
        events:{
            keyup:function(editor,event){
                let text=this.getText();
                let messageTo=editor.data("receiver");
                let messageContainer=$(".message-content");
                if(text !=""){
                    if(event.key==="Enter"){
                        let data={messageTo:messageTo,message:text,type:"NEW_MESSAGE"};
                        let date=new Date;
                        let time=date.toLocaleString('en-US',{
                            hour:"numeric",
                            hour12:true,
                            minute:"numeric"
                        });

                        let message='<div class="sender"><span class="sender-message-tail"> <img src="../assets/images/message-tail-sender.svg" alt=""> </span> <span class="sender-message">'+text+'</span> <span class="message-time">'+time+'</span> <span class="message-status"> <img src="../assets/images/double-check-unseen.svg" alt=""> </span> </div>';
                        messageContainer.append(message);
                        sendToOtherUser(conn,data);
                        this.setText('');
                        scrollItself();
                        userLoad();
                        
                    }
                }
            }
        }
    })
})