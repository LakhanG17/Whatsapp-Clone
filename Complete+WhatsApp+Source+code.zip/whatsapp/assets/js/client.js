var messageContainer=$(".message-content");
var receiver=$(".textArea").data("receiver");

var base_url="http://localhost/whatsapp/";
conn.onopen = function(e) {
    console.log("Connection established!");
};

conn.onmessage = function(e) {
   
    console.log(e.data);
    var data=JSON.parse(e.data);
    switch(data.type){
        case "CONNECTION_ESTABLISHED":
                $("#me-status").html('<h4>'+data.fullName+'</h4><span class="status-user">'+data.status+'</span>');
                userLoad(); 
        break; 
        case "NEW_USER_CONNECTED":
                if(receiver==data.userID){
                   $("#other-user-status").html('<h4>'+data.fullName+'</h4><span class="status-user">'+data.status+'</span>');
                   userLoad(); 
                }
                
        break;
        case "NEW_MESSAGE":
            if(data.messageFrom==receiver){
                let date=new Date;
                let time=date.toLocaleString('en-US',{
                    hour:"numeric",
                    hour12:true,
                    minute:"numeric"
                });

                let message='<div class="receiver"><span class="receiver-message-tail"> <img src="../assets/images/message-tail-receiver.svg" alt=""> </span> <span class="receiver-message">'+data.message+'</span> <span class="message-time">'+time+'</span></div>';
                messageContainer.append(message);
                scrollItself();
                userLoad();
            }
           
        break;
        case "NEW_IMAGE":
            if(data.messageFrom==receiver){
                let date=new Date;
                let time=date.toLocaleString('en-US',{
                    hour:"numeric",
                    hour12:true,
                    minute:"numeric"
                });

                let message='<div class="receiver message-image"><span class="receiver-message"><img src="' +base_url+data.message+ '"/></span> <span class="message-time">'+time+'</span></div>';
                messageContainer.append(message);
                scrollItself();
                userLoad();
            }
            
        break;
        case "NEW_AUDIO":
            if(data.messageFrom==receiver){
                let date=new Date;
                let time=date.toLocaleString('en-US',{
                    hour:"numeric",
                    hour12:true,
                    minute:"numeric"
                });

                let message='<div class="receiver audio-file"><span class="receiver-message"><audio src="' +base_url+data.message+ '" controls></audio></span> <span class="message-time">'+time+'</span></div>';
                messageContainer.append(message);
                scrollItself();
                userLoad();
            }
            
        break;
        case "USER_DISCONNECTED":
            if(receiver==data.userID){
                $(".message-header-content").html('<h4>'+data.fullName+'</h4><span class="status-user">'+data.status+'</span>');
            }
           
        break;
    }
    
};

function sendToOtherUser(connection, message) {
    connection.send(JSON.stringify(message));
}