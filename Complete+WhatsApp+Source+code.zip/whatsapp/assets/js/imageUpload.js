var base_url="http://localhost/whatsapp/";
$(document).on("change",".fileUpload",function(){
    var name=$(".fileUpload").val().split('\\').pop();
    var file_data=$(".fileUpload").prop("files")[0];
    var file_size=file_data['size'];
    var file_type=file_data['type'].split('/').pop();
    var error_images =[];
    var allow_files=['gif','png','jpg','jpeg'];
    var sender=$(".u-p-id").data('userid');
    var receiver=$(".u-p-id").data('profileid');
    var imgName='content/postImage/'+sender+'/'+name+'';

    if(file_size >2000000000){
        error_images += "File size is too large!";
    }

    
    var ext=name.split('.').pop().toLowerCase();
    if(jQuery.inArray(ext,allow_files)==-1){
        error_images += " Invalid file format!";
    }

   

    if(error_images==""){

        var form_data=new FormData();
        form_data.append("file",file_data);

        if(name != ""){
            $.post('http://localhost/whatsapp/core/ajax/postImage.php',{sender:sender,receiver:receiver,imgName:imgName},function(data){
                
            })

            $.ajax({
                url:"http://localhost/whatsapp/core/ajax/postImage.php",
                cache:false,
                contentType:false,
                processData:false,
                data:form_data,
                type:"POST",
                success:function(data){
                   
                    var data_result=JSON.parse(data);
                    if(data_result.status=="error"){  
                        $(".fileUpload").val("");
                        $(".files-error").addClass("show-file-error");
                        $(".files-error").html('<span class="files-cross-icon">&#x2715;</span>'+data_result.message+'');
                        setTimeout(function(){
                            $(".files-error").removeClass("show-file-error");
                        },5000);
                        return false;
                    }else{
                        let result={messageTo:receiver,message:data_result.message,type:"NEW_IMAGE"};
                        let date=new Date;
                        let time=date.toLocaleString('en-US',{
                            hour:"numeric",
                            hour12:true,
                            minute:"numeric"
                        });

                        let message='<div class="sender message-image"><span class="sender-message"><img src="' +base_url+data_result.message+ '"/></span> <span class="message-time">'+time+'</span></div>';
                        messageContainer.append(message);
                        sendToOtherUser(conn,result);
                        $(".fileUpload").val("");
                        scrollItself();
                        userLoad();
                    }
                }
            })
        }
    }else{
        $(".fileUpload").val("");
        $(".files-error").addClass("show-file-error");
        $(".files-error").html('<span class="files-cross-icon">&#x2715;</span>'+error_images+'');
        setTimeout(function(){
            $(".files-error").removeClass("show-file-error");
        },5000);
        return false;
    }

})