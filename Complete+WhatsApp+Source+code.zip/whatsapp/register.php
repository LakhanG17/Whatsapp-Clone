<?php

namespace MyApp;

require "core/init.php";



if ($loadFromUser->isLoggedIn()) {
    redirect_to(url_for("index.php"));
}
if (is_request_post()) {
    if (isset($_POST['submitButton'])) {
        $fname = FormSanitizer::sanitizeFormString($_POST['firstName']);
        $lname = FormSanitizer::sanitizeFormString($_POST['lastName']);
        $un = FormSanitizer::sanitizeFormUsername($_POST['username']);
        $em = FormSanitizer::sanitizeFormEmail($_POST['email']);
        $pw = FormSanitizer::sanitizeFormPassword($_POST['password']);

        $wasSuccessful = $account->register($fname, $lname, $un, $em, $pw);
        if ($wasSuccessful) {
            session_regenerate_id();
            $_SESSION['user_id'] = $wasSuccessful;
            redirect_to(url_for("index.php"));
        }
    }
}


?>
<?php require "shared/header.php"; ?>
<div class="signInContainer">
    <div class="column">
        <section class="header">
            <h3>Register</h3>
            <span>to continue to WhatsApp</span>
        </section>
        <form action="<?php echo h($_SERVER['PHP_SELF']); ?>" method="POST">
            <?php echo $account->getError(Constants::$firstNameCharacters); ?>
            <input type="text" name="firstName" placeholder="First Name......" value="<?php getInputValue('firstName'); ?>" required>
            <?php echo $account->getError(Constants::$lastNameCharacters); ?>
            <input type="text" name="lastName" placeholder="Last Name......" value="<?php getInputValue('lastName'); ?>" required>
            <?php echo $account->getError(Constants::$UsernameCharacters); ?>
            <?php echo $account->getError(Constants::$UsernameAlreadyTaken); ?>
            <input type="text" name="username" placeholder="Username......" value="<?php getInputValue('username'); ?>" required>
            <?php echo $account->getError(Constants::$EmailTaken); ?>
            <?php echo $account->getError(Constants::$emailInvalid); ?>
            <input type="email" name="email" placeholder="Email......" value="<?php getInputValue('email'); ?>" required>
            <?php echo $account->getError(Constants::$passwordTooShort); ?>
            <?php echo $account->getError(Constants::$passwordNotAlphaNumeric); ?>
            <input type="password" name="password" placeholder="Password......" required>
            <input type="submit" name="submitButton" value="Register">
        </form>
        <a href="login.php" class="logInMessage">Already have an account?LogIn Here!</a>

    </div>
</div>

</body>

</html>