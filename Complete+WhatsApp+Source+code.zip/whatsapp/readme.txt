To make whatsapp clone work, you must  install composer, php-cli, and ratchet

after that you must extract these files, use composer cmd composer update

And also, update your MySQL details in your Database.php from core/classes folder. And update your BASE URL in your init.php file from core/init folder and then update your domain links in your js file and your website root folder name in upload method

Please make sure you write review on the course page :) 

PDOStatement::bindParam() is use to bind variables to the parameter markers but to be given as input/output, by reference by reference means the variable you pass must exist and contain its original value. So when it execute the query the variables you bind must exist. But with the PDOStatement::bindValue()  you don't need the variable because you can pass with variable value to the PDOStatement::bindValue() method  as it does not requires the variable as a reference.

So when you have to bind multiple variable into your query using foreach loop maybe when you can use PDOStatement::bindValue() method

bindParam passes variable as reference and only evaluated when PDOStatement::execute() is called.

On the other hand bindValue allowed to pass variable as value and doesn't wait to call for PDOStatement::execute().
bindParam:

$user = 'userid';
$s = $dbh->prepare('SELECT first_name FROM users WHERE user_id= :userid');
$s->bindParam(':userid', $user);
$user = 'profileid';
$s->execute(); // executed with WHERE :userid = 'profileid'



$user = 'userid';
$s = $dbh->prepare('SELECT first_name FROM users WHERE user_id= :userid');
$s->bindValue(':userid', $user);
$user = 'profileid';
$s->execute(); // executed with WHERE :userid = 'userid'
