<?php

namespace MyApp;

require "core/init.php";
if ($loadFromUser->isLoggedIn()) {
    redirect_to(url_for("index.php"));
}

if (is_request_post()) {
    if (isset($_POST['loginButton'])) {
        $un = FormSanitizer::sanitizeFormUsername($_POST['un_em']);
        $pw = FormSanitizer::sanitizeFormPassword($_POST['password']);

        $wasSuccessful = $account->login($un, $pw);

        if ($wasSuccessful) {
            session_regenerate_id();
            $_SESSION['user_id'] = $wasSuccessful;
            redirect_to(url_for("index.php"));
        }
    }
}

$pageTitle = "Whatsapp || LogIn";
require "shared/header.php"; ?>
<div class="signInContainer">
    <div class="column">
        <section class="header">
            <h3>LogIn</h3>
            <span>to continue to WhatsApp</span>
        </section>
        <form action="<?php echo h($_SERVER['PHP_SELF']); ?>" method="POST">
            <?php echo $account->getError(Constants::$loginFailed); ?>
            <input type="text" name="un_em" placeholder="Email or Username......" value="<?php getInputValue('un_em'); ?>" required>
            <input type="password" name="password" placeholder="Password......" required>
            <input type="submit" name="loginButton" value="LogIn">
        </form>
        <a href="register.php" class="logInMessage">Need an account?Register Here!</a>

    </div>
</div>

</body>

</html>