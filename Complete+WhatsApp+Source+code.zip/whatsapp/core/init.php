<?php

ob_start();

session_start();

require_once "classes/Database.php";
require_once "classes/FormSanitizer.php";
require_once "classes/Constants.php";
require_once "classes/Account.php";
require_once "classes/User.php";
require_once "classes/Message.php";


$account = new \MyApp\Account();
$loadFromUser = new \MyApp\User;
$loadFromMessage = new \MyApp\Message;

define("WWW_ROOT", "http://localhost/whatsapp/");
require_once "functions.php";
