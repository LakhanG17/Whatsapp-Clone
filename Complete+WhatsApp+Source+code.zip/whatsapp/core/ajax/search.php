<?php

require "../init.php";
if (is_request_post()) {
    if (isset($_POST['search'])) {
        $search = trim(stripslashes(htmlentities($_POST['search'], ENT_QUOTES)));
        $userId = $_SESSION['user_id'];
        $users = $loadFromUser->search($search);
        if (count($users) === 0) {
            echo '<div class="sidebar-chat cursor-pointer bg-hover">
            <div class="chat-info">
                <h4>No Match Found</h4>
            </div>
        </div>';
        }

        foreach ($users as $user) {
            if ($user) {
                if ($user->userID != $userId) {
                    echo '<a href="' . url_for($user->username . '/messages') . '" class="sidebar-chat cursor-pointer bg-hover">
                        <div class="chat-avatar">
                            <img class="user-wrap-img" src="' . url_for($user->profileImage) . '" alt="' . $user->firstName . ' ' . $user->lastName . '">
                        </div>
                        <div class="chat-info">
                            <h4>' . $user->firstName . ' ' . $user->lastName . '</h4>
                        </div>
                    </a>';
                }
            }
        }
    }
}
