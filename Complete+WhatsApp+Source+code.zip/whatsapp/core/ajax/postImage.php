<?php

require "../init.php";
if (is_request_post()) {
    if (isset($_POST['sender']) && isset($_POST['receiver'])) {
        $userid = h($_POST['sender']);
        $receiver = h($_POST['receiver']);
        $postImage = $_POST['imgName'];

        $loadFromUser->create('messages', ['messageFrom' => $userid, 'messageTo' => $receiver, 'msg_type' => 'image', 'image' => $postImage]);
    }

    if (0 < $_FILES['file']['error']) {
        echo '{"status":"error","message":"' . $_FILES['file']['error'] . '"}';
    } else {
        $path_directory = $_SERVER['DOCUMENT_ROOT'] . "/whatsapp/content/postImage/" . $loadFromUser->userID . "/";
        if (!file_exists($path_directory) && !is_dir($path_directory)) {
            mkdir($path_directory, 0777, true);
        }

        move_uploaded_file($_FILES['file']['tmp_name'], $path_directory . $_FILES['file']['name']);
        echo '{"status":"success","message":"' . "content/postImage/" . $loadFromUser->userID . "/" . '' . $_FILES['file']['name'] . '"}';
    }
}
