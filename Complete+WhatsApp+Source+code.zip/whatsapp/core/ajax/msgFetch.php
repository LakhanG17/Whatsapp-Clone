<?php

require "../init.php";
if (is_request_post()) {
    if (isset($_POST['userId'])) {
        $userID = h($_POST['userId']);
        $profileId = h($_POST['profileId']);
        $allusermessages = $loadFromMessage->recentMessages($userID);
        $messageCount = $loadFromMessage->messageCount($userID);
        foreach ($allusermessages as $message) {
            $date = new \DateTime($message->messageOn);
            $active = ($message->userID == $profileId) ? "activeClass" : "";
            if ($message->msg_type == "audio") {
                echo '<a href="' . url_for($message->username . '/messages') . '" class="sidebar-chat cursor-pointer  bg-hover ' . $active . '">
                <div class="chat-avatar">
                    <img class="user-wrap-img" src="' . url_for($message->profileImage) . '" alt="' . $message->firstName . ' ' . $message->lastName
                    . '">
                </div>
                <div class="chat-info">
                    <h4>' . $message->firstName . ' ' . $message->lastName . '</h4>
                    <div class="image-wrap" style="display: flex;">
                        <img class="image-icon" src="' . url_for('assets/images/microphone-seen.svg') . '"/>
                        <span class="camera-text" style="margin-left: 10px;">Audio</span>
                    </div>
                </div>
                <div class="time">
                    <p>' . $date->format("h:i a") . '</p>
                    ' . (($message->status === 'notseen' && $message->messageFrom != $userID) ? '<span class="unread-messages-number">' . $messageCount->messageCount . '</span>' : '<img src="' . url_for('assets/images/double-check-seen.svg') . '" style="width:1.5rem;margin-top:10px;"/>') . '
                    
                </div>
            </a>';
            } else if ($message->msg_type == "image") {
                echo '<a href="' . url_for($message->username . '/messages') . '" class="sidebar-chat cursor-pointer  bg-hover ' . $active . '">
                <div class="chat-avatar">
                    <img class="user-wrap-img" src="' . url_for($message->profileImage) . '" alt="' . $message->firstName . ' ' . $message->lastName
                    . '">
                </div>
                <div class="chat-info">
                    <h4>' . $message->firstName . ' ' . $message->lastName . '</h4>
                    <div class="image-wrap" style="display: flex;">
                        <img class="image-icon" src="' . url_for('assets/images/camera-icon.svg') . '"/>
                        <span class="camera-text" style="margin-left: 10px;">Image</span>
                    </div>
                </div>
                <div class="time">
                    <p>' . $date->format("h:i a") . '</p>
                    ' . (($message->status === 'notseen' && $message->messageFrom != $userID) ? '<span class="unread-messages-number">' . $messageCount->messageCount . '</span>' : '<img src="' . url_for('assets/images/double-check-seen.svg') . '" style="width:1.5rem;margin-top:10px;"/>') . '
                    
                </div>
            </a>';
            } else {
                echo '<a href="' . url_for($message->username . '/messages') . '" class="sidebar-chat cursor-pointer  bg-hover ' . $active . '">
                <div class="chat-avatar">
                    <img class="user-wrap-img" src="' . url_for($message->profileImage) . '" alt="' . $message->firstName . ' ' . $message->lastName
                    . '">
                </div>
                <div class="chat-info">
                    <h4>' . $message->firstName . ' ' . $message->lastName . '</h4>
                    <p>' . $message->message . '</p>
                </div>
                <div class="time">
                    <p>' . $date->format("h:i a") . '</p>
                    ' . (($message->status === 'notseen' && $message->messageFrom != $userID) ? '<span class="unread-messages-number">' . $messageCount->messageCount . '</span>' : '<img src="' . url_for('assets/images/double-check-seen.svg') . '" style="width:1.5rem;margin-top:10px;"/>') . '
                    
                </div>
            </a>';
            }
        }
    }
}
