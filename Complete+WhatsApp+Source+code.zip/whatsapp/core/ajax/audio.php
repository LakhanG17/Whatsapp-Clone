<?php

require "../init.php";
if (is_request_post()) {
    if (isset($_FILES['audioFile']) && !empty($_FILES['audioFile'])) {
        $folder = $loadFromUser->audioUpload($_FILES['audioFile']);
        $receiver = $_POST['receiver'];
        $sender = $_POST['sender'];
        if ($sender == $loadFromUser->userID) {
            $loadFromUser->create('messages', ['messageFrom' => $sender, 'messageTo' => $receiver, 'msg_type' => 'audio', 'audio' => $folder]);
            if ($folder) {
                echo '{"status":"success","message":"' . $folder . '"}';
            } else {
                echo '{"status":"error","message":"Error Message"}';
            }
        }
    }
}
