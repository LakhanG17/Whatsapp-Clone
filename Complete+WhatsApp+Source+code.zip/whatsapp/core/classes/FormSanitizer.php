<?php

namespace MyApp;

// use PDO;


class FormSanitizer
{
    public static function sanitizeFormString($data)
    {
        $data = strip_tags($data);
        $data = trim($data);
        $data = strtolower($data);
        $data = ucfirst($data);
        return $data;
    }
    public static function sanitizeFormUsername($data)
    {
        $data = strip_tags($data);
        $data = trim($data);
        $data = strtolower($data);
        return $data;
    }
    public static function sanitizeFormPassword($data)
    {
        $data = strip_tags($data);
        return $data;
    }
    public static function sanitizeFormEmail($data)
    {
        $data = htmlentities($data, ENT_QUOTES);
        $data = stripcslashes($data);
        $data = trim($data);
        return $data;
    }
}
