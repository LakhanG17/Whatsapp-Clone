<?php

namespace MyApp;

// use PDO;

class Constants
{
    public static $firstNameCharacters = "First Name must be between 2 and 25 Characters";
    public static $lastNameCharacters = "Last Name must be between 2 and 25 Characters";
    public static $UsernameCharacters = "Username  must be between 2 and 25 Characters";
    public static $passwordTooShort = "Password too short";
    public static $passwordNotAlphaNumeric = "Password not alphanumeric";
    public static $loginFailed = "Password or Username is incorrect";
    public static $UsernameAlreadyTaken = "Username  Already in use";
    public static $EmailTaken = "Email  Already in use";
    public static $emailInvalid = "Email is Invalid";
}
