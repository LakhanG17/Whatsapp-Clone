<?php

namespace MyApp;

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class Chat implements MessageComponentInterface
{
    protected $clients;

    public $userData, $userObj;

    public function __construct()
    {
        $this->clients = new \SplObjectStorage;
        $this->userObj = new \MyApp\User;
    }

    public function onOpen(ConnectionInterface $conn)
    {
        $queryString = $conn->httpRequest->getUri()->getQuery();
        parse_str($queryString, $query);
        if ($data = $this->userObj->getUserBySessionID($query['token'])) {
            $this->userData = $data;
            $conn->userData = $data;

            $conn->send(json_encode(array(
                "type" => "CONNECTION_ESTABLISHED",
                "status" => "Online",
                "username" => $data->username,
                "fullName" => $data->firstName . ' ' . $data->lastName,
                "connId" => $data->connectionID,
                "userID" => $data->userID
            )));

            foreach ($this->clients as $client) {
                $client->send(json_encode(array(
                    "type" => "NEW_USER_CONNECTED",
                    "status" => "Online",
                    "username" => $data->username,
                    "fullName" => $data->firstName . ' ' . $data->lastName,
                    "connId" => $data->connectionID,
                    "userID" => $data->userID
                )));
            }
            // Store the new connection to send messages to later
            $this->clients->attach($conn);

            $this->userObj->update("users", ['connectionID' => $conn->resourceId, 'onlineStatus' => "Online"], ['userID' => $data->userID]);

            echo "New connection! ({$data->username})\n";
        }
    }

    public function onMessage(ConnectionInterface $from, $msg)
    {
        $numRecv = count($this->clients) - 1;
        echo sprintf(
            'Connection %d sending message "%s" to %d other connection%s' . "\n",
            $from->resourceId,
            $msg,
            $numRecv,
            $numRecv == 1 ? '' : 's'
        );
        $data = json_decode($msg, true);
        $senderData = $this->userObj->userData($data['messageTo']);

        if ($data['type'] === "NEW_MESSAGE") {
            $this->userObj->create("messages", ['message' => $data['message'], 'messageFrom' => $from->userData->userID, 'messageTo' => $data['messageTo']]);
        }
        $send['messageFrom'] = $from->userData->userID;
        $send['messageTo'] = $senderData->userID;
        $send['message'] = $data['message'];
        $send['type'] = $data['type'];
        $send['username'] = $from->userData->username;
        foreach ($this->clients as $client) {
            if ($from !== $client) {
                if ($client->resourceId == $senderData->connectionID || $from == $client) {
                    // The sender is not the receiver, send to each client connected
                    $client->send(json_encode($send));
                }
            }
        }
    }

    public function onClose(ConnectionInterface $conn)
    {
        $queryString = $conn->httpRequest->getUri()->getQuery();
        parse_str($queryString, $query);
        if ($data = $this->userObj->getUserBySessionID($query['token'])) {
            $this->userData = $data;
            $conn->userData = $data;
            foreach ($this->clients as $client) {
                $client->send(json_encode(array(
                    "type" => "USER_DISCONNECTED",
                    "status" => "Offline",
                    "username" => $data->username,
                    "fullName" => $data->firstName . ' ' . $data->lastName,
                    "connId" => $data->connectionID,
                    "userID" => $data->userID
                )));
            }
            // The connection is closed, remove it, as we can no longer send it messages
            $this->clients->detach($conn);

            $this->userObj->update("users", ['connectionID' => $conn->resourceId, 'onlineStatus' => "Offline"], ['userID' => $data->userID]);

            echo "Connection {$data->username} has disconnected\n";
        }
    }

    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }
}
