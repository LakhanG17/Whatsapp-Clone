<?php

namespace MyApp;


use PDO;



class Message
{
    public $pdo;
    public $userID;
    public $user;
    public function __construct()
    {
        $db = new \MyApp\Database;
        $this->user = new \MyApp\User;
        $this->pdo = $db->connect();
    }

    public function recentMessages($userID)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM `messages` LEFT JOIN `users` On `messageFrom`=`userID` AND `messageID` IN (SELECT max(`messageID`) FROM `messages` WHERE `messageFrom`=`userID`) WHERE `messageTo`=:userID AND `messageFrom`=`userID` GROUP BY `userID` ORDER BY `messageID` DESC");
        $stmt->bindValue(":userID", $userID, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    public function messageCount($userID)
    {
        $stmt = $this->pdo->prepare('SELECT count(*) AS messageCount FROM messages LEFT JOIN users On   messages.messageFrom=users.userID WHERE messages.messageTo=:userID AND messages.messageFrom !=:userID AND messages.status="notseen"');
        $stmt->bindValue(":userID", $userID, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_OBJ);
    }

    public function updateMessageStatus($messageFrom)
    {

        $this->user->update("messages", ['status' => "seen"], ['messageFrom' => $messageFrom, 'messageTo' => $this->user->userID]);
    }

    public function messageData($messageTo)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM `messages` LEFT JOIN `users` ON `messageFrom`=`userID`
         WHERE (`messageFrom`=:userID AND `messageTo`=:senderID) OR (`messageFrom`=:senderID AND `messageTo`=:userID)");
        $stmt->bindParam(":userID", $this->user->userID, PDO::PARAM_INT);
        $stmt->bindParam(":senderID", $messageTo, PDO::PARAM_INT);
        $stmt->execute();
        $messages = $stmt->fetchAll(PDO::FETCH_OBJ);
        foreach ($messages as $message) {
            $date = new \DateTime($message->messageOn);
            if ($message->messageFrom == $this->user->userID) {
                if ($message->msg_type == "audio") {
                    echo '<div class="sender audio-file">
                <span class="sender-message"><audio src="' . url_for($message->audio) . '" controls></audio></span>
                <span class="message-time">' . $date->format("h:i a") . '</span>
            </div>';
                } else if ($message->msg_type == "image") {
                    echo '<div class="sender message-image">
                <span class="sender-message"><img src="' . url_for($message->image) . '"/></span>
                <span class="message-time">' . $date->format("h:i a") . '</span>
            </div>';
                } else {
                    echo '<div class="sender"><span class="sender-message-tail">
                    <img src="' . url_for('assets/images/message-tail-sender.svg') . '" alt="">
                </span>
                <span class="sender-message">' . $message->message . '</span>
                <span class="message-time">' . $date->format("h:i a") . '</span>
                <span class="message-status">
                ' . (($message->status === "seen") ? ' <img src="' . url_for('assets/images/double-check-seen.svg') . '" alt="">' : ' <img src="' . url_for('assets/images/double-check-unseen.svg') . '" alt="">') . '   
                </span>
            </div>';
                }
            } else {
                if ($message->msg_type == "audio") {
                    echo '<div class="receiver audio-file">
                <span class="receiver-message"><audio src="' . url_for($message->audio) . '" controls></audio></span>
                <span class="message-time">' . $date->format("h:i a") . '</span>
            </div>';
                } else if ($message->msg_type == "image") {
                    echo '<div class="receiver message-image">
                    <span class="receiver-message"><img src="' . url_for($message->image) . '"/></span>
                    <span class="message-time">' . $date->format("h:i a") . '</span>
                </div>';
                } else {
                    echo '<div class="receiver">
                <span class="receiver-message-tail">
                    <img src="' . url_for('assets/images/message-tail-receiver.svg') . '" alt="">
                </span>
                <span class="receiver-message">' . $message->message . '</span>
                <span class="message-time">' . $date->format("h:i a") . '</span>
            </div>';
                }
            }
        }
    }
}
