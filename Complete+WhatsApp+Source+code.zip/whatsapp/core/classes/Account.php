<?php

namespace MyApp;

use PDO;


class Account
{
    public $pdo;
    private $errorArray = array();

    public function __construct()
    {
        $pdo = new \MyApp\Database();
        $this->pdo = $pdo->connect();
    }

    public function register($fn, $ln, $un, $em, $pw)
    {
        $this->validateFirstName($fn);
        $this->validateLastName($ln);
        $this->validateUsername($un);
        $this->validateEmail($em);
        $this->validatePassword($pw);
        if (empty($this->errorArray)) {
            return $this->insertUserData($fn, $ln, $un, $em, $pw);
        } else {
            return false;
        }
    }
    private function validateFirstName($fn)
    {
        if ($this->length($fn, 2, 25)) {
            return   array_push($this->errorArray, Constants::$firstNameCharacters);
        }
    }

    private function validateLastName($ln)
    {
        if ($this->length($ln, 2, 25)) {
            return   array_push($this->errorArray, Constants::$lastNameCharacters);
        }
    }
    private function validatePassword($pw)
    {
        if ($this->length($pw, 5, 25)) {
            return   array_push($this->errorArray, Constants::$passwordTooShort);
        }

        if (preg_match("/[^A-Za-z0-9]/", $pw)) {
            return   array_push($this->errorArray, Constants::$passwordNotAlphaNumeric);
        }
    }

    private function validateUsername($un)
    {
        if ($this->length($un, 2, 25)) {
            return   array_push($this->errorArray, Constants::$UsernameCharacters);
        }

        $stmt = $this->pdo->prepare("SELECT `username` FROM users WHERE username=:un");
        $stmt->bindValue(":un", $un, PDO::PARAM_STR);
        $stmt->execute();
        if ($stmt->rowCount() > 0) {
            return   array_push($this->errorArray, Constants::$UsernameAlreadyTaken);
        }
    }

    private function validateEmail($em)
    {
        $stmt = $this->pdo->prepare("SELECT `email` FROM users WHERE email=:em");
        $stmt->bindValue(":em", $em, PDO::PARAM_STR);
        $stmt->execute();
        if ($stmt->rowCount() > 0) {
            return   array_push($this->errorArray, Constants::$EmailTaken);
        }

        if (!filter_var($em, FILTER_VALIDATE_EMAIL)) {
            return   array_push($this->errorArray, Constants::$emailInvalid);
        }
    }
    public function login($un, $pw)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE email=:em OR username=:em");
        $stmt->bindValue(":em", $un, PDO::PARAM_STR);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_OBJ);
        if (!empty($user)) {
            if (password_verify($pw, $user->password)) {
                return $user->userID;
            } else {
                array_push($this->errorArray, Constants::$loginFailed);
                return false;
            }
        } else {
            array_push($this->errorArray, Constants::$loginFailed);
            return  false;
        }
        // if ($stmt->rowCount() > 0) {
        //    
        // }
    }


    private function insertUserData($fn, $ln, $un, $em, $pw)
    {
        $pass_hash = $this->hash($pw);
        $rand = rand(0, 2);
        if ($rand == 0) {
            $profilePic = "assets/images/avatar.png";
        } else if ($rand == 1) {
            $profilePic = "assets/images/defaultProfilePic.png";
        } else if ($rand == 2) {
            $profilePic = "assets/images/profilePic.jpeg";
        }

        $stmt = $this->pdo->prepare("INSERT INTO users (firstName,lastName,username,email,password,profileImage) VALUES (:fn,:ln,:un,:em,:pw,:pic)");
        $stmt->bindParam(":fn", $fn, PDO::PARAM_STR);
        $stmt->bindParam(":ln", $ln, PDO::PARAM_STR);
        $stmt->bindParam(":un", $un, PDO::PARAM_STR);
        $stmt->bindParam(":em", $em, PDO::PARAM_STR);
        $stmt->bindParam(":pw", $pass_hash, PDO::PARAM_STR);
        $stmt->bindParam(":pic", $profilePic);
        $stmt->execute();

        return $this->pdo->lastInsertId();
    }

    private function hash($password)
    {
        return password_hash($password, PASSWORD_BCRYPT);
    }
    private function length($input, $min, $max)
    {
        if (strlen($input) < $min) {
            return true;
        } else if (strlen($input) > $max) {
            return true;
        }
    }

    public function getError($error)
    {
        if (in_array($error, $this->errorArray)) {
            return "<span class='errorMessage'>$error</span>";
        }
    }
}
