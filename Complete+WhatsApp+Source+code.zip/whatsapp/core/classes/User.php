<?php

namespace MyApp;

use PDO;

class User
{
    public $pdo, $userID, $sessionID;
    public function __construct()
    {
        $db = new \MyApp\Database;
        $this->pdo = $db->connect();
        $this->userID = $this->ID();
        $this->sessionID = $this->getSessionId();
    }

    public function ID()
    {
        if ($this->isLoggedIn()) {
            return $_SESSION['user_id'];
        }
    }

    public function userData($userID = "")
    {
        $userID = ((!empty($userID)) ? $userID : $this->userID);
        return $this->get('users', ['*'], ['userID' => $userID]);
    }
    public function getUserBySessionID($sessionID)
    {
        return $this->get('users', ['*'], ['sessionID' => $sessionID]);
    }
    public function getUserByUsername($username)
    {
        return $this->get('users', ['*'], ['username' => $username]);
    }
    public function getSessionId()
    {
        return session_id();
    }

    public function updateSession()
    {
        $this->update("users", ['sessionID' => $this->sessionID], ['userID' => $this->userID]);
    }
    public function isLoggedIn()
    {
        return (isset($_SESSION['user_id']) ? true : false);
    }

    public function search($search)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE `username` LIKE ?  OR `firstName` LIKE ?  OR  `lastName` LIKE ? ");
        $stmt->bindValue(1, $search . '%', PDO::PARAM_STR);
        $stmt->bindValue(2, $search . '%', PDO::PARAM_STR);
        $stmt->bindValue(3, $search . '%', PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    public function get($table, $column = array(), $fields = array())
    {

        $targetColumn = implode(", ", array_values($column));
        $columns = "";
        $counter = 1;
        foreach ($fields as $name => $values) {
            $columns .= "{$name}=:{$name}";
            if ($counter < count($fields)) {
                $columns .= " AND ";
            }
            $counter++;
        }
        $sql = "SELECT {$targetColumn} FROM `{$table}` WHERE {$columns} ";
        if ($stmt = $this->pdo->prepare($sql)) {
            foreach ($fields as $key => $values) {
                $stmt->bindValue(":" . $key, $values);
            }
            $stmt->execute();
            // echo "<pre>";
            // $stmt->debugDumpParams();
            // echo "</pre>";
            return $stmt->fetch(PDO::FETCH_OBJ);
        }
    }
    public function create($table,  $fields = array())
    {

        $columns = implode(", ", array_keys($fields));
        $values = ':' . implode(", :", array_keys($fields));

        $sql = "INSERT INTO `{$table}` ({$columns}) VALUES ({$values})";
        if ($stmt = $this->pdo->prepare($sql)) {
            foreach ($fields as $key => $values) {
                $stmt->bindValue(":" . $key, $values);
            }
            $stmt->execute();
            return $this->pdo->lastInsertId();
        }
    }


    public function update($table, $fields, $cond)
    {
        $columns = "";
        $where = " WHERE ";
        $i = 1;
        foreach ($fields as $name => $values) {
            $columns .= "{$name}=:{$name}";
            if ($i < count($fields)) {
                $columns .= " , ";
            }
            $i++;
        }
        $sql = "UPDATE `{$table}` SET {$columns} ";
        foreach ($cond as $key => $value) {
            $sql .= " {$where} `{$key}` =:{$key}";
            $where = " AND ";
        }
        if ($stmt = $this->pdo->prepare($sql)) {
            foreach ($fields as $key => $values) {
                $stmt->bindValue(":" . $key, $values);
                foreach ($cond as $key => $value) {
                    $stmt->bindValue(":" . $key, $value);
                }
            }
            $stmt->execute();
        }
    }

    public function audioUpload($file)
    {
        $fileInfo = $file['tmp_name'];

        $fileTmp = $file['tmp_name'];
        $fileName = $file['name'];
        $fileType = $file['type'];

        $fileSize = $file['size'];
        $fileError = $file['error'];

        $ext = explode('/', $fileType);
        $ext = strtolower(end($ext));



        $path_directory = $_SERVER['DOCUMENT_ROOT'] . "/whatsapp/content/media/" . $this->userID . '/';
        if (!file_exists($path_directory) && !is_dir($path_directory)) {
            mkdir($path_directory, 0777, true);
        }
        $folder = "content/media/" . $this->userID . '/' . substr(md5(time() . mt_rand()), 2, 25) . "." . $ext;
        $path_files = $_SERVER['DOCUMENT_ROOT'] . "/whatsapp/" . $folder;
        if ($fileError === 0) {
            move_uploaded_file($fileTmp, $path_files);
            return $folder;
        }
    }
}
