<?php

namespace MyApp;

require "core/init.php";
if (!$loadFromUser->isLoggedIn()) {
    redirect_to(url_for("register.php"));
}
if (isset($_GET['username']) && !empty($_GET['username'])) {
    $username = FormSanitizer::sanitizeFormUsername($_GET['username']);
    $profileData = $loadFromUser->getUserByUsername($username);
    if (!$profileData) {
        redirect_to(url_for("index.php"));
    }
    $profileId = $profileData->userID;
    $pageTitle = "Chat with " . $profileData->firstName . ' ' . $profileData->lastName;
    $loadFromMessage->updateMessageStatus($profileId);
}

$loadFromUser->updateSession();
$userData = $loadFromUser->userData();

?>
<?php require "shared/header.php"; ?>
<div class="u-p-id" data-userid="<?php echo $userData->userID; ?>" data-profileid="<?php echo $profileId; ?>"></div>
<div class="r-container">
    <div class="r-wrapper">
        <button id="stopRecording">Stop Recording</button>
    </div>
</div>
<aside class="sidebar">
    <header class="header">
        <div class="chat-header-left">
            <div class="user-wrap">
                <img class="user-wrap-img" src="<?php echo url_for($userData->profileImage); ?>" alt=" <?php echo $userData->firstName . ' ' . $userData->lastName; ?>">
            </div>
            <span class="user-header-name">
                <?php echo $userData->firstName . ' ' . $userData->lastName; ?>
            </span>
        </div>
        <div class="chat-header-right">
            <img src="<?php echo url_for('assets/images/circle-notch-solid.svg'); ?>" alt="Circle notch Icon">
            <img src="<?php echo url_for('assets/images/chat.svg'); ?>" alt="Chat Icon">
            <img src="<?php echo url_for('assets/images/more.svg'); ?>" alt="Settings Icon">
        </div>
    </header>
    <section class="sidebar-search">
        <div class="search-wrap">
            <img src="<?php echo url_for('assets/images/search-solid.svg'); ?>" alt="Search Icon">
            <input type="text" placeholder="Search a User" class="search-user">
        </div>
    </section>
    <section class="recentMessages">

    </section>
    <section class="search-result hidden">

    </section>
</aside>
<main class="message-container">
    <header class="header">
        <div class="chat-header-left">
            <div class="user-wrap">
                <img class="user-wrap-img" src="<?php echo url_for($profileData->profileImage); ?>" alt=" <?php echo $profileData->firstName . ' ' . $profileData->lastName; ?>">
            </div>
            <div class="message-header-content" id="other-user-status">
                <h4><?php echo $profileData->firstName . ' ' . $profileData->lastName; ?></h4>
                <span class="status-user"><?php echo $profileData->onlineStatus; ?></span>
            </div>
        </div>
        <div class="chat-header-right">
            <a href="<?php echo url_for('logout.php') ?>">Logout</a>
        </div>
    </header>
    <section class="message-content" style="overflow-y: scroll;flex:1;padding:20px 80px;display:flex;flex-direction:column;">
        <?php $loadFromMessage->messageData($profileId); ?>
    </section>
    <div class="files-error">

    </div>
    <section class="message-footer">
        <div class="message-footer-left">

            <div class="attach-file">
                <img src="<?php echo url_for('assets/images/paper-clip.svg'); ?>" alt="File Upload">
                <input type="file" name="fileUpload" class="fileUpload">
            </div>
        </div>
        <div class="message-footer-center">
            <input type="text" name="textArea" class="textArea" placeholder="Type a message...." data-receiver="<?php echo $profileId; ?>" data-sender="<?php echo $userData->userID; ?>">
        </div>
        <div class="message-footer-right" id="startRecording">
            <img src=" <?php echo url_for('assets/images/audio-icon.svg'); ?>" alt="Audio Icon">
        </div>
    </section>
</main>

<script src="<?php echo url_for("assets/js/jquery.js"); ?>"></script>
<script src="<?php echo url_for("assets/dist/emojionearea.min.js"); ?>"></script>
<script src="<?php echo url_for("assets/js/liveSearch.js"); ?>"></script>
<script src="<?php echo url_for("assets/js/msgFetch.js"); ?>"></script>
<script>
    const conn = new WebSocket('ws://localhost:8080/whatsapp/?token=<?php echo $loadFromUser->sessionID; ?>');

    function scrollItself() {
        var elViewHeight = $(".message-content").height();
        var elTotalHeight = $(".message-content")[0].scrollHeight;
        if (elTotalHeight > elViewHeight) {
            $(".message-content").scrollTop(elTotalHeight - elViewHeight);
        }
    }

    scrollItself();
</script>
<script src="<?php echo url_for("assets/js/client.js"); ?>"></script>
<script src="<?php echo url_for("assets/js/messages.js"); ?>"></script>
<script src="<?php echo url_for("assets/js/imageUpload.js"); ?>"></script>
<script src="<?php echo url_for("assets/js/audio.js"); ?>"></script>
</body>

</html>