-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2021 at 01:04 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `whatsapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageID` int(11) NOT NULL,
  `message` text NOT NULL,
  `messageFrom` int(11) NOT NULL,
  `messageTo` int(11) NOT NULL,
  `messageOn` datetime NOT NULL DEFAULT current_timestamp(),
  `msg_type` enum('text','image','audio') NOT NULL DEFAULT 'text',
  `image` varchar(255) NOT NULL,
  `audio` varchar(255) NOT NULL,
  `status` enum('seen','notseen') NOT NULL DEFAULT 'notseen'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profileImage` varchar(255) NOT NULL,
  `sessionID` varchar(255) NOT NULL,
  `connectionID` int(11) NOT NULL,
  `onlineStatus` enum('online','offline') NOT NULL DEFAULT 'offline'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `firstName`, `lastName`, `username`, `email`, `password`, `profileImage`, `sessionID`, `connectionID`, `onlineStatus`) VALUES
(1, 'Daniel', 'Laryea', 'daniel', 'daniel@gmail.com', '$2y$10$dHZJ1uEtEHDvEhbjJqyCfOp8LrbOODfDN92IFtfJLDgSGxGIB.baW', 'assets/images/avatar.png', 'v0mb78rrotucvnfacn1kjh7v7u', 85, 'online'),
(2, 'Christian', 'Attoh', 'christian', 'christian@gmail.com', '$2y$10$AhUgTESwrfA/TP5.EnXpjuBT0Urog7A7ZfTUZTHYpK7GSc1mUWzU2', 'assets/images/profilePic.jpeg', '1lroj3q8bfhq1f0j73jq018vgh', 54, 'online'),
(3, 'Christiana', 'Larbi', 'flamboyant', 'larbi@gmail.com', '$2y$10$4uym9OeBm6GabfH4wcLigeNWfYgofwLjz41N.5V2bz2ca8csqypvK', 'assets/images/profilePic.jpeg', 'evg8munp7r9g4qdd0cqgeebu9p', 126, 'offline'),
(4, 'Andrews', 'Andoh', 'andrews', 'andoh@gmail.com', '$2y$10$IiePPEj0lN9FenUYgoBq5.cwgFYZYNfoQh9IiZfTYIPZi1wbmSfGG', 'assets/images/avatar.png', '', 0, 'offline'),
(5, 'Bruce', 'Pobi', 'brucepobi', 'brucepobi@gmail.com', '$2y$10$9dcUNuP.Kb4tQEUfkVKSCutPcW6bXsG4qoq/1MbSQS10bfLtvaNPO', 'assets/images/profilePic.jpeg', '', 0, 'offline'),
(6, 'Chris', 'Brown', 'chrisbrown', 'chrisbrown@gmail.com', '$2y$10$ZSqB8DA9h7woHqWC9nDUXunzNa/K.U6C7PWHsuEtiNDhIKseiRu8e', 'assets/images/avatar.png', 'babrvifpkeff8k7dd9ro4qm1u7', 156, 'offline'),
(7, 'Kwame Gameli', 'Attoh', 'kwameattoh', 'kwameattoh@gmail.com', '$2y$10$UuOohgspm9ue7AAcTs.Wxer8iVLGAAA1UOoxofJzPUJaRqopLP7CO', 'assets/images/profilePic.jpeg', '', 0, 'offline'),
(8, 'James', 'Otu', 'otu', 'james@gmail.com', '$2y$10$5MjRYeTbyyGYmf5EdicnMeouSEY1lHAjv9zxMu/JRc2F6sn7jZ75S', 'assets/images/profilePic.jpeg', 'j45ge2jeqc358hdi4o2anfmjer', 0, 'offline');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
