<?php

require "core/init.php";
if (!$loadFromUser->isLoggedIn()) {
    redirect_to(url_for("register.php"));
}
$pageTitle = "Welcome to WhatsApp || Home";
$loadFromUser->updateSession();
$userData = $loadFromUser->userData();
$profileId = "";
?>
<?php require "shared/header.php"; ?>
<div class="u-p-id" data-userid="<?php echo $userData->userID; ?>" data-profileid="<?php echo $profileId; ?>"></div>
<aside class="sidebar">
    <header class="header">
        <div class="chat-header-left">
            <div class="user-wrap">
                <img class="user-wrap-img" src="<?php echo url_for($userData->profileImage); ?>" alt=" <?php echo $userData->firstName . ' ' . $userData->lastName; ?>">
            </div>
            <span class="user-header-name">
                <?php echo $userData->firstName . ' ' . $userData->lastName; ?>
            </span>
        </div>
        <div class="chat-header-right">
            <img src="<?php echo url_for('assets/images/circle-notch-solid.svg'); ?>" alt="Circle notch Icon">
            <img src="<?php echo url_for('assets/images/chat.svg'); ?>" alt="Chat Icon">
            <img src="<?php echo url_for('assets/images/more.svg'); ?>" alt="Settings Icon">
        </div>
    </header>
    <section class="sidebar-search">
        <div class="search-wrap">
            <img src="<?php echo url_for('assets/images/search-solid.svg'); ?>" alt="Search Icon">
            <input type="text" placeholder="Search a User" class="search-user">
        </div>
    </section>
    <section class="recentMessages">

    </section>
    <section class="search-result hidden">

    </section>
</aside>
<main class="message-container">
    <header class="header">
        <div class="chat-header-left">
            <div class="user-wrap">
                <img class="user-wrap-img" src="<?php echo url_for($userData->profileImage); ?>" alt=" <?php echo $userData->firstName . ' ' . $userData->lastName; ?>">
            </div>
            <div class="message-header-content" id="me-status">
                <h4><?php echo $userData->firstName . ' ' . $userData->lastName; ?></h4>
                <span class="status-user">Online</span>
            </div>
        </div>
        <div class="chat-header-right">
            <a href="<?php echo url_for('logout.php') ?>">Logout</a>
        </div>
    </header>
    <section class="message-banner"></section>
</main>

<script src="<?php echo url_for("assets/js/jquery.js"); ?>"></script>
<script src="<?php echo url_for("assets/js/liveSearch.js"); ?>"></script>
<script src="<?php echo url_for("assets/js/msgFetch.js"); ?>"></script>
<script>
    const conn = new WebSocket('ws://localhost:8080/whatsapp/?token=<?php echo $loadFromUser->sessionID; ?>');
</script>
<script src="<?php echo url_for("assets/js/client.js"); ?>"></script>
</body>

</html>